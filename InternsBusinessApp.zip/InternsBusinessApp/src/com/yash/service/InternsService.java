package com.yash.service;
import java.util.List;
import java.util.Optional;
import com.yash.model.InternsModel;
public interface InternsService {
	List<InternsModel> retrieveInternsService();
	List<InternsModel> retrieveInternsService(String sortBy);
	Optional<InternsModel> retrieveInternsByIdService(int internId);
	String registerInternService(InternsModel internsModel);
	String updateInternService(InternsModel internsModel);
	String updateInternLevelService(InternsModel internsModel);
	String removeInternService(int internId);
}
