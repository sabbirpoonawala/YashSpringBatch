package com.yash.service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import com.yash.dao.InternsDAO;
import com.yash.entity.Interns;
import com.yash.exception.InternsException;
import com.yash.helper.FactoryInterns;
import com.yash.model.InternsModel;
import com.yash.entity.Level;
public class InternsServiceImpl implements InternsService {
	public InternsServiceImpl() {
		this.internsDAO=FactoryInterns.createInternsDAO();
	}
	private InternsDAO internsDAO;
	public List<InternsModel> retrieveInternsService() {
		// TODO Auto-generated method stub
		Map<Integer,Interns> interns= internsDAO.getAllInterns();
		List<Interns> internsList=interns.values().stream().collect(Collectors.toList());
		List<InternsModel> internsModelList=new ArrayList<>();
		internsList.forEach((intern)->{
			InternsModel model=new InternsModel();
			model.setId(intern.getId());
			model.setInternFirstName(intern.getInternFirstName());
			model.setInternLastName(intern.getInternLastName());
			model.setInternAge(intern.getInternAge());
			model.setLevel(intern.getLevel().toString());
			internsModelList.add(model);
		});
		if(interns.isEmpty()){
			throw new InternsException("No interns records found");
		}else{	
			return internsModelList;
		}
	}
	@Override
	public Optional<InternsModel> retrieveInternsByIdService(int internId) {
		// TODO Auto-generated method stub
		Optional<Interns> internOptional=internsDAO.getInternById(internId);
		InternsModel model=new InternsModel();
		if(internOptional.isPresent()) {
			Interns intern=internOptional.get();
		model.setId(intern.getId());
		model.setInternFirstName(intern.getInternFirstName());
		model.setInternLastName(intern.getInternLastName());
		model.setInternAge(intern.getInternAge());
		model.setLevel(intern.getLevel().toString());
	    }else {
			throw new InternsException("Intern not found");
		}
		return Optional.of(model);
	}
	public Level determineLevelBySemesterMarks(InternsModel internsModel){
		int sem1Marks=internsModel.getSemester1Marks();
		int sem2Marks=internsModel.getSemester2Marks();
		int sem3Marks=internsModel.getSemester3Marks();
		int semAverage=(sem1Marks+sem2Marks+sem3Marks)/3;
		if(semAverage<=50){
			throw new InternsException("Intern did not match eligibility");
		}
		if(semAverage>50 && semAverage<=60){
			return Level.BEGINNER;
		}else if(semAverage>60 && semAverage<70){
			return Level.INTERMEDIATE;
		}else{
			return Level.ADVANCED;
		}
	}
	@Override
	public String registerInternService(InternsModel internsModel) {
		// TODO Auto-generated method stub			
		Level level=determineLevelBySemesterMarks(internsModel);
		
		Interns interns=new Interns();
		interns.setId(internsModel.getId());
		interns.setInternFirstName(internsModel.getInternFirstName());
		interns.setInternLastName(internsModel.getInternLastName());
		interns.setInternAge(internsModel.getInternAge());
		interns.setLevel(level);
		boolean isInternRegistered=internsDAO.storeInternData(interns);
		if(isInternRegistered)
			return "success";
		else
			return "fail";
	}
	@Override
	public String updateInternService(InternsModel internsModel) {
		// TODO Auto-generated method stub
		Level level=determineLevelBySemesterMarks(internsModel);
		Interns interns=new Interns();
		interns.setId(internsModel.getId());
		interns.setInternFirstName(internsModel.getInternFirstName());
		interns.setInternLastName(internsModel.getInternLastName());
		interns.setInternAge(internsModel.getInternAge());
		interns.setLevel(level);		
		boolean checkUpdation=internsDAO.updateIntern(interns);
		if(checkUpdation==false)
			throw new InternsException("Updation failed.....");
	    if(checkUpdation)
	    	return "success";
	    else
	        return "fail";
	}
	@Override
	public String updateInternLevelService(InternsModel internsModel) {
		// TODO Auto-generated method stub
		Level level=determineLevelBySemesterMarks(internsModel);
		Interns interns=new Interns();
		interns.setId(internsModel.getId());
		interns.setLevel(level);
		boolean checkUpdation=internsDAO.updateInternLevel(interns);
		if(checkUpdation==false)
			throw new InternsException("Updation failed.....");
		 if(checkUpdation)
		    	return "success";
		    else
		        return "fail";
	}
	@Override
	public String removeInternService(int internId) {
		// TODO Auto-generated method stub
		boolean checkRemoval=internsDAO.removeIntern(internId);
		if(checkRemoval==false)
			throw new InternsException("Deletion failed....");
		if(checkRemoval)
			return "success";
		else
			return "fail";
	}
	@Override
	public List<InternsModel> retrieveInternsService(String sortBy) {
		// TODO Auto-generated method stub
		List<InternsModel> internsModelList=retrieveInternsService();
		switch(sortBy) {
		case "InternFirstName":
			                   Comparator<InternsModel> sortByFirstName=(model1,model2)->{ 
			                   return model1.getInternFirstName().compareTo(model2.getInternFirstName());
			                   };
			                   Collections.sort(internsModelList,sortByFirstName);
			                   break;       
		case "InternLastName":
			                   Comparator<InternsModel> sortByLastName=(model1,model2)->{ 
             	               return model1.getInternFirstName().compareTo(model2.getInternFirstName());
                               };
                               Collections.sort(internsModelList,sortByLastName);
                               break;
		case "InternAge":
			                   Comparator<InternsModel> sortByAge=(model1,model2)->{ 
	                           if(model1.getInternAge()>model2.getInternAge()) {
	                        	   return 1;
	                           }else if(model1.getInternAge()<model2.getInternAge()) {
	                        	   return -1;
	                           }else {
	                        	   return 0;
	                           }
                               };
                                Collections.sort(internsModelList,sortByAge);
                                break;
          default:
        	                    Comparator<InternsModel> sortById=(model1,model2)->{ 
                                if(model1.getId()>model2.getId()) {
               	                return 1;
                                }else if(model1.getId()<model2.getId()) {
               	                return -1;
                                }else {
               	                return 0;
                                }
                                };
                               Collections.sort(internsModelList,sortById);
                               break;
		}
		return internsModelList;
	}
}
