package com.yash.controller;
import java.util.List;
import com.yash.helper.FactoryInterns;
import com.yash.model.InternsModel;
import com.yash.service.InternsService;
import com.yash.validation.InternsModelValidator;
import com.yash.view.InternsView;
import com.yash.view.MainView;
public class InternsController {
	private InternsService internsService;
	InternsView internView=new InternsView();
	public InternsController() {
		this.internsService=FactoryInterns.createInternsService();
	}
   public void handleRetrieveInterns(RequestType request) {
		List<InternsModel> models=internsService.retrieveInternsService();
		MainView mainView=new MainView();
		switch(request) {
		
		case NAME: internView.showInternName(models);
		           mainView.viewInternMenu();
			       break;
		case LEVEL:internView.showInternLevel(models);
		           mainView.viewInternMenu();
			       break;
		default:   mainView.invalidOption();
			       break;
		
		}
	}
   
   public void handleRetrieveSortedInterns(SortType sortType) {
		MainView mainView=new MainView();
		switch(sortType) {
		
		case ID  : List<InternsModel> internsModelListSortedById=internsService.retrieveInternsService("ID");
			       internView.showSortedIntern(internsModelListSortedById);
		           mainView.viewSortedInternMenu();
			       break;
		case INTERNFIRSTNAME:
			       List<InternsModel> internsModelListSortedByFirstName=internsService.retrieveInternsService("InternFirstName");
		           internView.showSortedIntern(internsModelListSortedByFirstName);
		           mainView.viewSortedInternMenu();
		           break;

		case INTERNLASTNAME:
		           List<InternsModel> internsModelListSortedByLastName=internsService.retrieveInternsService("InternLastName");
	               internView.showSortedIntern(internsModelListSortedByLastName);
		           mainView.viewSortedInternMenu();
		           break;

		case INTERNAGE:
		           List<InternsModel> internsModelListSortedByAge=internsService.retrieveInternsService("InternAge");
	               internView.showSortedIntern(internsModelListSortedByAge);
		           mainView.viewSortedInternMenu();
		           break;

		default:  mainView.invalidOption();
			      break;
		}
   }
	public void handleRegisterIntern(InternsModel model) {
		InternsModelValidator validator=new InternsModelValidator();
		if(validator.validate(model)) {
		String outcome=internsService.registerInternService(model);
		if(outcome.contentEquals("success")) {
			internView.showRegistrationSuccess(model);	
		}else {
			internView.showRegistrationFailure(model);
		}
	}else {
		internView.validationFailedError();
	}
	}
	public void handleUpdateIntern(InternsModel model) {
		String outcome=internsService.updateInternService(model);
		if(outcome.contentEquals("success")) {
			internView.showInternUpdateSuccess(model);	
		}else {
			internView.showInternUpdateFailure(model);
		}
		
	}
	public void handleUpdateInternLevel(InternsModel model) {
		String outcome=internsService.updateInternLevelService(model);
		if(outcome.contentEquals("success")) {
			internView.showInternLevelUpdateSuccess(model);	
		}else {
			internView.showInternLevelUpdateFailure(model);
		}
	}
	
	public void handleDeleteIntern(InternsModel model) {
		String outcome=internsService.removeInternService(model.getId());
		if(outcome.contentEquals("success")) {
			internView.showDeleteSuccess(model);	
		}else {
			internView.showDeleteFailure(model);
		}
	}
}
