package com.yash.controller;
public enum RequestType {
	NAME("name"),LEVEL("level"),SORT("sort");
	private String val;
	private RequestType(String val) {
		this.val=val;
	}
	public String getVal() {
		return val;
	}
}
