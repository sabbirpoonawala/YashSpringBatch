package com.yash.controller;
public enum SortType {
	ID("ID"),INTERNFIRSTNAME("INTERNFIRSTNAME"),INTERNLASTNAME("INTERNLASTNAME"),INTERNAGE("INTERNAGE");
	private String val;
	private SortType(String val) {
		this.val=val;
	}
	public String getVal() {
		return val;
	}
}
