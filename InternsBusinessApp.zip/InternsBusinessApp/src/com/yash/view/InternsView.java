package com.yash.view;
import java.util.List;
import java.util.function.Consumer;
import com.yash.model.InternsModel;
public class InternsView {
 private MainView mainView=new MainView();
 Consumer<InternsModel> consumerName= intern-> {
	 System.out.println("Intern Id:"+intern.getId());
	 System.out.println("Full Name:"+intern.fullName()+"\n");
	 
 
 };
 Consumer<InternsModel> consumerLevel= intern->{ 
	 System.out.println("Intern Id:"+intern.getId());
	 System.out.println("Level:"+intern.getLevel()+"\n");
	 
 
 };
 Consumer<InternsModel> consumerSortedInterns= intern-> 
 {
	 System.out.println("Id:"+intern.getId()+"\n");
	 System.out.println("Intern First Name:"+intern.getInternFirstName()+"\n");
	 System.out.println("Intern Last Name:"+intern.getInternLastName()+"\n");
	 System.out.println("Intern Age:"+intern.getInternAge()+"\n");
	 System.out.println("Intern Level:"+intern.getLevel()+"\n");
 };
 
  public static void print(List<InternsModel> models, Consumer<InternsModel> consumer){
  for(InternsModel model:models){
    consumer.accept(model);
   }
 }
	public void showInternName(List<InternsModel> models) {
		print(models,consumerName);
	}
	public void showInternLevel(List<InternsModel> models) {
		print(models,consumerLevel);
	}
	public void showSortedIntern(List<InternsModel> models) {
		print(models,consumerSortedInterns);	
	}
	public void showRegistrationSuccess(InternsModel model) {
		
		System.out.println("\n Registration successful for Intern id=>"+model.getId());
		mainView.mainMenu();
	}
	
	public void showRegistrationFailure(InternsModel model) {
		System.out.println("\n Registration unsuccessful for Intern id=>"+model.getId());
		mainView.mainMenu();
	}
	
   public void showInternUpdateSuccess(InternsModel model) {
		System.out.println("\n successful updated for Intern id=>"+model.getId());
		mainView.mainMenu();
	}
	
	public void showInternUpdateFailure(InternsModel model) {
		System.out.println("\n Level updated failed for Intern id=>"+model.getId());
		mainView.mainMenu();
	}
	
	public void showInternLevelUpdateSuccess(InternsModel model) {
		System.out.println("\n Level successfully updated for Intern id=>"+model.getId());
		mainView.mainMenu();
	}
	
	public void showInternLevelUpdateFailure(InternsModel model) {
		System.out.println("\n Level updated failed for Intern id=>"+model.getId());
		mainView.mainMenu();
	}

	public void showDeleteSuccess(InternsModel model){
		System.out.println("\n Intern record deleted for Intern id=>"+model.getId());
			
	}
	  public void showDeleteFailure(InternsModel model){
			System.out.println("\n Intern record deletion failed for Intern id=>"+model.getId());	
	}	
	
	  public void validationFailedError() {
		  System.out.println("Data validation failed!!");
	  }
}
	
	


