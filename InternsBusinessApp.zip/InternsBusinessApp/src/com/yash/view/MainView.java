package com.yash.view;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import com.yash.controller.InternsController;
import com.yash.controller.RequestType;
import com.yash.controller.SortType;
import com.yash.exception.ValidationException;
import com.yash.model.InternsModel;
import com.yash.validation.InternsModelValidator;
public class MainView {
	public void mainMenu() {
		System.out.println("\n");
		System.out.println("\t \t ========Main Menu========");
		System.out.println("=>1. View Interns Details");
		System.out.println("=>2  View Sorted Intern Details");
		System.out.println("=>3. Register Intern");
		System.out.println("=>4. Update Intern");
		System.out.println("=>5. Update Intern Level");
		System.out.println("=>6. Delete Intern");
		System.out.println("=>7. Exit");
		try(Scanner scanner=new Scanner(System.in);){
			System.out.print("\nOption:");
			int option=scanner.nextInt();
			switch(option) {
			case 1:viewInternMenu();
			       break;
			case 2:viewSortedInternMenu();
			       break;
			case 3:registerInternForm();
				   break;
			case 4:updateInternForm();
				   break;
			case 5:updateInternLevelForm();
			       break;
			case 6:deleteEmployeeForm();
				   break;
			case 7:System.exit(0);
			   break;
			default:System.out.println("!ERROR[SELECT APPROPRIATE OPTION]");
			        mainMenu();			  
			}
			
		}catch(Exception e) {
			
			System.out.println("!ERROR[SELECT APPROPRIATE OPTION]");
		}
	}
	public void viewInternMenu() {
		try(
				Scanner scanner=new Scanner(System.in);
		){
			System.out.println("1. View Intern Name");
			System.out.println("2. View Intern Level");
			System.out.println("3. Main Menu");
			System.out.print("Enter choice:");
			int option=scanner.nextInt();
			InternsController internController=new InternsController();
			
			if(option==1)
				internController.handleRetrieveInterns(RequestType.NAME);
			if(option==2)
				internController.handleRetrieveInterns(RequestType.LEVEL);
            if(option==3)
            	mainMenu();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
public void viewSortedInternMenu() {
		try(
				Scanner scanner=new Scanner(System.in);
		){
			System.out.println("1. Sort based on  Intern Id");
			System.out.println("2. Sort based on  Intern FirstName");
			System.out.println("3. Sort based on  Intern LastName");
			System.out.println("4. Sort based on  Intern Age");
			System.out.println("5. Main Menu");
			System.out.print("Enter choice:");
			int option=scanner.nextInt();
			InternsController internController=new InternsController();	
			if(option==1)
				internController.handleRetrieveSortedInterns(SortType.ID);
			if(option==2)
				internController.handleRetrieveSortedInterns(SortType.INTERNFIRSTNAME);
			if(option==3)
				internController.handleRetrieveSortedInterns(SortType.INTERNLASTNAME);
			if(option==4)
				internController.handleRetrieveSortedInterns(SortType.INTERNAGE);
            if(option==5)
            	mainMenu();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
public void registerInternForm() {
		try(Scanner scanner=new Scanner(System.in);){
			int id=0;
			System.out.print("Intern Id:");
			if(scanner.hasNextInt()) {
			id=scanner.nextInt();
			}
			else {
				try {
					throw new ValidationException("[!ERROR:Invalid Employee Id]");
					}catch(ValidationException e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
						mainMenu();
					}
			}
			InternsModelValidator validator=new InternsModelValidator();
			System.out.print("First Name:");
			String internFirstName=scanner.next();
			boolean validfirstName=validator.validString(internFirstName);
			if(!validfirstName)
				try {
				throw new ValidationException("[!ERROR:Invalid First Name]");
				}catch(ValidationException e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
					mainMenu();
				}			
			System.out.print("Last Name:");
			String internLastName=scanner.next();
			
			boolean validLastName=validator.validString(internLastName);
			if(!validLastName)
				try {
				throw new ValidationException("[!ERROR:Invalid Last Name]");
				}catch(ValidationException e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
					mainMenu();
				}
			System.out.print("Date of Birth(DD/MM/YYYY):");
			String dobDateString=scanner.next();
			
			StringTokenizer tokens=new StringTokenizer(dobDateString,"/");
			List<String> tokensList=new ArrayList<>();
			while(tokens.hasMoreTokens()) {
				tokensList.add(tokens.nextToken());
			}
			int dayOfMonth=Integer.parseInt(tokensList.get(0));
			int month=Integer.parseInt(tokensList.get(1));
			int year=Integer.parseInt(tokensList.get(2));
			LocalDate dateOfBirth=LocalDate.of(year, month-1, dayOfMonth);
			LocalDate now=LocalDate.now();
			Period diff = Period.between(dateOfBirth, now);
			int internAge=diff.getYears();
			boolean validAge=validator.validAge(internAge);
			if(!validAge)
				try {
				throw new ValidationException("[!ERROR:Invalid Age]");
				}catch(ValidationException e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
					mainMenu();
				}
			int semester1Marks=0;
			System.out.print("Semester 1 Marks:");
			if(scanner.hasNextInt()) {
				semester1Marks=scanner.nextInt();
			}
			else {
				try {
					throw new ValidationException("[!ERROR:Invalid Semester Marks]");
					}catch(ValidationException e) {
						System.out.println(e.getMessage());
						mainMenu();
					}
			}
			int semester2Marks=0;
			System.out.print("Semester 2 Marks:");
			if(scanner.hasNextInt()) {
				semester2Marks=scanner.nextInt();
			}
			else {
				try {
					throw new ValidationException("[!ERROR:Invalid Semester Marks]");
					}catch(ValidationException e) {
						System.out.println(e.getMessage());
						mainMenu();
					}
			}
			
			int semester3Marks=0;
			System.out.print("Semester 3 Marks:");
			if(scanner.hasNextInt()) {
				semester3Marks=scanner.nextInt();
			}
			else {
				try {
					throw new ValidationException("[!ERROR:Invalid Semester Marks]");
					}catch(ValidationException e) {
						System.out.println(e.getMessage());
						mainMenu();
					}
			}			
			InternsModel model=new InternsModel();
			model.setId(id);
			model.setInternFirstName(internFirstName);
			model.setInternLastName(internLastName);
			model.setInternAge(internAge);
			model.setSemester1Marks(semester1Marks);
			model.setSemester2Marks(semester2Marks);
			model.setSemester3Marks(semester3Marks);
			
			InternsController controller=new InternsController();
			controller.handleRegisterIntern(model);
			
		   mainMenu();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

public void updateInternForm() {
	try(Scanner scanner=new Scanner(System.in);){
		InternsModelValidator validator=new InternsModelValidator();
		int id=0;
		System.out.print("Id:");
		if(scanner.hasNextInt()) {
		id=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Id]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		System.out.print("First Name:");
		String internFirstName=scanner.next();
		
		boolean validfirstName=validator.validString(internFirstName);
		if(!validfirstName)
			try {
			throw new ValidationException("[!ERROR:Invalid First Name]");
			}catch(ValidationException e) {
				System.out.println(e.getMessage());
				mainMenu();
			}
		System.out.print("Last Name:");
		String internLastName=scanner.next();
		boolean validLastName=validator.validString(internLastName);
		if(!validLastName)
			try {
			throw new ValidationException("[!ERROR:Invalid Last Name]");
			}catch(ValidationException e) {
				System.out.println(e.getMessage());
				mainMenu();
			}
		System.out.print("Date of Birth(DD/MM/YYYY):");
		String dobDateString=scanner.next();
		
		StringTokenizer tokens=new StringTokenizer(dobDateString,"/");
		
		List<String> tokensList=new ArrayList<>();
		while(tokens.hasMoreTokens()) {
			tokensList.add(tokens.nextToken());
		}
		
		int dayOfMonth=Integer.parseInt(tokensList.get(0));
		int month=Integer.parseInt(tokensList.get(1));
		int year=Integer.parseInt(tokensList.get(2));
		LocalDate dateOfBirth=LocalDate.of(year, month-1, dayOfMonth);
		LocalDate now=LocalDate.now();
		Period diff = Period.between(dateOfBirth, now);
		int internAge=diff.getYears();
		
		boolean validsalary=validator.validAge(internAge);
		if(!validsalary)
			try {
			throw new ValidationException("[!ERROR:Invalid Age]");
			}catch(ValidationException e) {
				System.out.println(e.getMessage());
				mainMenu();
			}
		
		int semester1Marks=0;
		System.out.print("Semester 1 Marks:");
		if(scanner.hasNextInt()) {
			semester1Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		int semester2Marks=0;
		System.out.print("Semester 2 Marks:");
		if(scanner.hasNextInt()) {
			semester2Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		int semester3Marks=0;
		System.out.print("Semester 3 Marks:");
		if(scanner.hasNextInt()) {
			semester3Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		InternsModel model=new InternsModel();
		model.setId(id);
		model.setInternFirstName(internFirstName);
		model.setInternLastName(internLastName);
		model.setInternAge(internAge);
		model.setSemester1Marks(semester1Marks);
		model.setSemester2Marks(semester2Marks);
		model.setSemester3Marks(semester3Marks);
		
		InternsController controller=new InternsController();
		controller.handleUpdateIntern(model);
		
	   mainMenu();
	}catch(Exception e) {
		System.out.println("!Error processing request. Please try again later");
	}
}

public void updateInternLevelForm() {
	try(Scanner scanner=new Scanner(System.in);){
		InternsModelValidator validator=new InternsModelValidator();
		int id=0;
		System.out.print("Id:");
		if(scanner.hasNextInt()) {
		id=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Id]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		int semester1Marks=0;
		System.out.print("Semester 1 Marks:");
		if(scanner.hasNextInt()) {
			semester1Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		int semester2Marks=0;
		System.out.print("Semester 2 Marks:");
		if(scanner.hasNextInt()) {
			semester2Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		
		int semester3Marks=0;
		System.out.print("Semester 3 Marks:");
		if(scanner.hasNextInt()) {
			semester3Marks=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Semester Marks]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}
		InternsModel model=new InternsModel();
		model.setId(id);
		model.setSemester1Marks(semester1Marks);
		model.setSemester2Marks(semester2Marks);
		model.setSemester3Marks(semester3Marks);
		
		InternsController controller=new InternsController();
		controller.handleUpdateIntern(model);
		
	   mainMenu();
	}catch(Exception e) {
		System.out.println("!Error processing request. Please try again later");
	}
}

public void deleteEmployeeForm() {
	try(Scanner scanner=new Scanner(System.in);){
		
		int id=0;
		System.out.print("Id:");
		if(scanner.hasNextInt()) {
		id=scanner.nextInt();
		}
		else {
			try {
				throw new ValidationException("[!ERROR:Invalid Employee Id]");
				}catch(ValidationException e) {
					System.out.println(e.getMessage());
					mainMenu();
				}
		}		
		InternsModel model=new InternsModel();
		model.setId(id);
		InternsController controller=new InternsController();
		controller.handleDeleteIntern(model);
		
	   mainMenu();
	}catch(Exception e) {
		System.out.println("!Error processing request. Please try again later");
	}
}
    public void invalidOption() {
	System.out.println("!Error Invalid option");
}
	}

