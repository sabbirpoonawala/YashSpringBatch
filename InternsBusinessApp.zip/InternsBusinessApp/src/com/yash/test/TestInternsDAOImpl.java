package com.yash.test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.yash.dao.MemoryInternsDAOImpl;
import com.yash.entity.Interns;
import com.yash.entity.Level;
class TestInternsDAOImpl {
	private MemoryInternsDAOImpl internsDAOImpl=null;
	@BeforeEach
	void setUp() throws Exception {
		internsDAOImpl=new MemoryInternsDAOImpl();
		Interns testData=new Interns();
		testData.setId(1001);
		testData.setInternFirstName("sabbir");
		testData.setInternLastName("poonawala");
		testData.setInternAge(34);
		testData.setLevel(Level.INTERMEDIATE);
		internsDAOImpl.storeInternData(testData);
	}

	@AfterEach
	void tearDown() throws Exception {
		internsDAOImpl=null;
	}

	@Test
	void testGetAllInterns_positive() {
		Map<Integer,Interns> internsMap=internsDAOImpl.getAllInterns();
		assertEquals(internsMap.size()>0,true);
	}
	@Test
	void testGetInternById_positive() {
      Optional<Interns> internsOptional=internsDAOImpl.getInternById(1001);
      assertEquals(1001,internsOptional.get().getId());
	}
	@Test
	void testStoreInternData_positive() {
		Interns intern=new Interns();
		intern.setId(1002);
		intern.setInternFirstName("amit");
		intern.setInternLastName("kumar");
		intern.setInternAge(21);
		intern.setLevel(Level.BEGINNER);
		boolean internStored=internsDAOImpl.storeInternData(intern);
		assertEquals(true,internStored);
	}
	@Test
	void testUpdateIntern_positive() {
		Interns internUpdate=new Interns();
		internUpdate.setId(1001);
		internUpdate.setInternFirstName("amit");
		internUpdate.setInternLastName("kumar");
		internUpdate.setInternAge(21);
		internUpdate.setLevel(Level.INTERMEDIATE);
		boolean internUpdated=internsDAOImpl.updateIntern(internUpdate);
		assertEquals(true,internUpdated);
	}
	@Test
	void testUpdateInternLevel_positive() {
		Interns internUpdateLevel=new Interns();
		internUpdateLevel.setId(1001);
		internUpdateLevel.setLevel(Level.ADVANCED);
		boolean internUpdatedLevel=internsDAOImpl.updateInternLevel(internUpdateLevel);
		assertEquals(true,internUpdatedLevel);
	}
	@Test
	void testRemoveIntern_positive() {
		boolean internDeleted=internsDAOImpl.removeIntern(1001);
		assertEquals(true,internDeleted);
	}
}
