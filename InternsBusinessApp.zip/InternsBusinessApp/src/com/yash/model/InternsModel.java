package com.yash.model;
public class InternsModel  {
	private int id;
	private String internFirstName;
	private String internLastName;
	private int internAge;
	private String level;
	private int semester1Marks;
	private int semester2Marks;
	private int semester3Marks;
	public InternsModel() {}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInternFirstName() {
		return internFirstName;
	}
	public void setInternFirstName(String internFirstName) {
		this.internFirstName = internFirstName;
	}
	public String getInternLastName() {
		return internLastName;
	}
	public void setInternLastName(String internLastName) {
		this.internLastName = internLastName;
	}

	public int getInternAge() {
		return internAge;
	}

	public void setInternAge(int internAge) {
		this.internAge = internAge;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public int getSemester1Marks() {
		return semester1Marks;
	}

	public void setSemester1Marks(int semester1Marks) {
		this.semester1Marks = semester1Marks;
	}

	public int getSemester2Marks() {
		return semester2Marks;
	}

	public void setSemester2Marks(int semester2Marks) {
		this.semester2Marks = semester2Marks;
	}

	public int getSemester3Marks() {
		return semester3Marks;
	}

	public void setSemester3Marks(int semester3Marks) {
		this.semester3Marks = semester3Marks;
	}
	
	public String fullName() {
		return internFirstName+internLastName;
	}
}
