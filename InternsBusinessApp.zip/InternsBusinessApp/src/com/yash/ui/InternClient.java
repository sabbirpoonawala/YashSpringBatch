package com.yash.ui;
import com.yash.view.MainView;
public class InternClient {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainView mainView=new MainView();
		mainView.mainMenu();
	}
}
