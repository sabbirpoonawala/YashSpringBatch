package com.yash.helper;
import com.yash.dao.InternsDAO;
import com.yash.dao.MemoryInternsDAOImpl;
import com.yash.service.InternsService;
import com.yash.service.InternsServiceImpl;
public class FactoryInterns {
	public static InternsDAO createInternsDAO() {
		InternsDAO internsDAO=new MemoryInternsDAOImpl();
		return internsDAO;
	}
	public static InternsService createInternsService() {
		InternsService internsService=new InternsServiceImpl();
		return internsService;
	}

}
