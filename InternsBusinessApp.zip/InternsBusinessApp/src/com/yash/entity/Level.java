package com.yash.entity;
public enum Level {
	BEGINNER(0),INTERMEDIATE(1),ADVANCED(2);
	private int level;
	private Level(int level) {
		this.level=level;
	}
	public int getLevel() {
		return level;
	}
}
