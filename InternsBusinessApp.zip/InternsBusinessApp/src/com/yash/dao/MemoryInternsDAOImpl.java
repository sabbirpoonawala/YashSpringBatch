package com.yash.dao;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import com.yash.entity.Interns;
public class MemoryInternsDAOImpl implements InternsDAO{
	private static Map<Integer,Interns> internsMap=new HashMap<>();
	public MemoryInternsDAOImpl() {
	}
	public static <T> Collector<T, ?, T> toSingleton() {
	    return Collectors.collectingAndThen(
	            Collectors.toList(),
	            list -> {
	                if (list.size() != 1) {
	                    throw new IllegalStateException();
	                }
	                return list.get(0);
	            }
	    );
	}
	@Override
	public Map<Integer,Interns> getAllInterns() {
		// TODO Auto-generated method stub
		return internsMap;
	}
	@Override
	public Optional<Interns> getInternById(int internId) {
		// TODO Auto-generated method stub
		Set<Map.Entry<Integer,Interns>> entries=internsMap.entrySet();
	    Map.Entry<Integer,Interns> internEntry=entries.stream()
	    		.filter((entry)->entry.getKey()==internId)
	    		.collect(toSingleton());
        return Optional.ofNullable(internEntry.getValue());
	}
	@Override
	public boolean storeInternData(Interns intern) {
		// TODO Auto-generated method stub
		internsMap.put(intern.getId(), intern);
		boolean[] internStored= {false};
		internsMap.forEach((k,v)->{
			if(k==intern.getId()) {
				internStored[0]=true;
			}
		});
		return internStored[0];
	}
	@Override
	public boolean updateIntern(Interns intern) {
		// TODO Auto-generated method stub
		boolean[] internUpdated= {false};
		internsMap.forEach((k,v)->{
			if(k.equals(intern.getId())) {
				internsMap.put(intern.getId(),intern);
				internUpdated[0]=true;	
			}
		});
		if(internUpdated[0])
		return true;
		else
		return false;
	}
	@Override
	public boolean updateInternLevel(Interns intern) {
		boolean[] internUpdated= {false};
		internsMap.forEach((k,v)->{
			if(k.equals(intern.getId())) {
				Interns interns=internsMap.get(intern.getId());
				interns.setLevel(intern.getLevel());
				internsMap.put(k, interns);
				internUpdated[0]=true;	
			}
		});
		if(internUpdated[0])
		return true;
		else
		return false;
	}
	@Override
	public boolean removeIntern(int internId) {
		// TODO Auto-generated method stub
		Set<Map.Entry<Integer,Interns>> entries=internsMap.entrySet();
		   Map.Entry<Integer,Interns> internEntry=entries.stream()
		    		.filter((entry)->entry.getKey()==internId)
		    		.collect(toSingleton());
		internsMap.remove(internEntry.getKey());
		 boolean ifDeleted[]= {false};
		internsMap.forEach((k,v)->{
			if(k!=internId) {
				ifDeleted[0]=true;
			}	
		});
		if(internsMap.isEmpty()) {
			ifDeleted[0]=true;
		}
		return ifDeleted[0];
	}
}
