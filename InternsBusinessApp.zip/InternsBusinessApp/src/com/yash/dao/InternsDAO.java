package com.yash.dao;
import java.util.Map;
import java.util.Optional;
import com.yash.entity.Interns;
public interface InternsDAO {
	Map<Integer,Interns> getAllInterns();
	Optional<Interns> getInternById(int internId);
	boolean storeInternData(Interns intern);
	boolean updateIntern(Interns intern);
	boolean updateInternLevel(Interns intern);
	boolean removeIntern(int internId);
}
