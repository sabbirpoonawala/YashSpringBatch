package com.yash.exception;
public class InternsException extends RuntimeException {
	private String message;
	public InternsException(String message) {
		super(message);
	}
	public String getMessage() {
		return message;
	}
}
