package com.yash.test;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockServletContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.yash.controller.StudentController;
import com.yash.dao.JDBCStudentDAOImpl;
import com.yash.integrate.ConnectionManager;
import com.yash.integrate.DataSource;
import com.yash.main.SpringRestMain;
import com.yash.model.StudentResponse;
import com.yash.security.AuthenticationEntryPoint;
import com.yash.security.SpringSecurityConfig;
import com.yash.service.StudentService;
import com.yash.service.StudentServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MockServletContext.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        classes = {SpringRestMain.class}
     )   		

public class TestStudentRestAppSecurity {

	private MockMvc mockMvc;
	@Autowired
	private FilterChainProxy springSecurityFilterChain;
	
	@Spy
	@Autowired
	private StudentServiceImpl studentServiceImpl;
	@Spy
	@Autowired
	private JDBCStudentDAOImpl jdbcStudentDAOImpl;
	@Spy
	@Autowired
	private ConnectionManager connectionManager;
	@Spy
	@Autowired
	private DataSource dataSource;
	
	 @InjectMocks
	 private StudentController studentController;
	 
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .apply(SecurityMockMvcConfigurers.springSecurity(springSecurityFilterChain))
	                .build();
	    }
    
	
		@Test
		//@WithUserDetails("yashuser")
		@WithMockUser(username = "jjjjj",password = "user123")
		public void test_auth_positive() throws Exception {			
			        mockMvc.perform(MockMvcRequestBuilders.get("/student-app/students")
		            .accept(MediaType.ALL))
		            .andExpect(status().isOk());
		}

}
