package com.yash.proxy;

public interface SomeInterface {
	
	public int someMethod();

}
