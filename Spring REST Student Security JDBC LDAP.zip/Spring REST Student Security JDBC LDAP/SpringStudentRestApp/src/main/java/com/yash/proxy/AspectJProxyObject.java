package com.yash.proxy;

import org.apache.log4j.Logger;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.aspect.DebuggingAspect;
import com.yash.controller.StudentController;

public class AspectJProxyObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Create object to be proxied
		

		
		StudentController studentController = new StudentController();

		//Create the Proxy Factory
		AspectJProxyFactory proxyFactory = new AspectJProxyFactory(studentController);

		//Add Aspect class to the factory
		proxyFactory.addAspect(DebuggingAspect.class);

		//Get the proxy object
		StudentController proxyStudentController = proxyFactory.getProxy();

		//Invoke the proxied method
		
		proxyStudentController.retrieveAllStudents();
		

	}

}
