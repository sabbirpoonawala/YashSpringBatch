package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.integrate.ConnectionManager;
@Repository
public class JDBCStudentDAOImpl implements StudentDAO {
	@Autowired
	private ConnectionManager manager;

	public List<Student> getAllStudents() throws StudentDAOException {
		// TODO Auto-generated method stub
		Connection connection;
		List<Student> studentList=new ArrayList<Student>();

		try {
			connection = manager.openConnection();
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery("select * from student");
			while(resultSet.next()) {
				Student student=new Student();
				student.setRollNo(resultSet.getInt("roll_no"));
				student.setStudentName(resultSet.getString("student_name"));
				student.setStudentAddress(resultSet.getString("student_address"));
				studentList.add(student);
			}
		} catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");
		}
	
		return studentList;
	}

	public Student getStudentByRollNo(int rollNo) throws StudentDAOException {
		// TODO Auto-generated method stub
		Student student=new Student();
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=
					connection.prepareStatement("select * from student where roll_no=?");
			statement.setInt(1, rollNo);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next()) {
				student.setRollNo(resultSet.getInt("roll_no"));
				student.setStudentName(resultSet.getString("student_name"));
				student.setStudentAddress(resultSet.getString("student_address"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new StudentDAOException(e,"Data access exception");
		} 
		
		return student;
	}

	public boolean registerStudentData(Student student) throws StudentDAOException {
		// TODO Auto-generated method stub
		int rows=0;
		try {
		Connection connection=manager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("insert into student(roll_No,student_name,student_address) values(?,?,?)");
		statement.setInt(1, student.getRollNo());
		statement.setString(2, student.getStudentName());
		statement.setString(3,student.getStudentAddress());
		rows=statement.executeUpdate();
		}catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");

		}
		if(rows>0)
			return true;
		else
		return false;
	}

	public boolean updateStudentData(Student student) throws StudentDAOException {
		// TODO Auto-generated method stub
		int rows=0;
		try {
		Connection connection=manager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("update student set student_name=?,student_address=? "
						+ "where roll_no=?");
		statement.setString(1, student.getStudentName());
		statement.setString(2, student.getStudentAddress());
		statement.setInt(3, student.getRollNo());
		rows=statement.executeUpdate();
		System.out.println("rows:"+rows);
		}catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");
		}
		if(rows>0)
			return true;
		else
		return false;	
		}

	
	public boolean updateStudentAddress(int rollNo,String newAddress) throws StudentDAOException {
		// TODO Auto-generated method stub
		int rows=0;
		try {
		Connection connection=manager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("update student set student_address=? where roll_no=?");
		
		statement.setString(1, newAddress);
		statement.setInt(2, rollNo);
		rows=statement.executeUpdate();
		System.out.println("rows:"+rows);
		}catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");

		}
		if(rows>0)
			return true;
		else
		return false;	
		}	

	
	public boolean deleteStudent(int rollNo) throws StudentDAOException {
		// TODO Auto-generated method stub
		int rows=0;
		try {
		Connection connection=manager.openConnection();
		PreparedStatement statement=
				connection.prepareStatement("delete from student where roll_no=?");
		
		statement.setInt(1, rollNo);
		rows=statement.executeUpdate();
		System.out.println("rows:"+rows);
		}catch(Exception e) {
			throw new StudentDAOException(e,"Data access exception");

		}
		if(rows>0)
			return true;
		else
		return false;	}

}
