package com.yash.service;

import java.util.List;

import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

public interface StudentService {
	public List<StudentResponse> studentRetrievalService();
	public StudentResponse studentRetrievalServiceByRollNo(int rollNo);
	public boolean studentRegistrationService(StudentRequest studentRequest);
	public boolean updateStudentService(StudentRequest studentRequest);
	public boolean updateStudentAddressService(int rollNo,String newAddress);
	public boolean deleteStudentService(int rollNo);
	
}
