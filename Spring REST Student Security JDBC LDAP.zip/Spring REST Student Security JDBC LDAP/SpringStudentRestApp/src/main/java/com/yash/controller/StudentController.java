package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.custom.CustomHttpStatus;
import com.yash.model.StudentError;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.validation.StudentRequestValidator;

@RestController
@RequestMapping("student-app")
@EnableAspectJAutoProxy
public class StudentController {
	@Autowired
	private StudentService studentService;
	//@Autowired
	//private StudentRequestValidator validator;
	
	@GetMapping("students")
	@PreAuthorize ("hasRole('ROLE_DEVELOPERS') or hasRole('ROLE_MANAGERS')")
	//@PreAuthorize ("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public ResponseEntity<List<StudentResponse>> retrieveAllStudents(){
		
		List<StudentResponse> studentResponseList=studentService.studentRetrievalService();
		ResponseEntity<List<StudentResponse>> response=
				new ResponseEntity<List<StudentResponse>>(studentResponseList,HttpStatus.OK);
		return response;
		
	}
	@GetMapping("students/{rollNo}")
	@PreAuthorize (value="hasRole('userrole') or hasRole('adminrole')")
	public ResponseEntity<StudentResponse> retrieveStudentByRollNo(@PathVariable("rollNo") int rollNo){
		StudentResponse studentResponse=studentService.studentRetrievalServiceByRollNo(rollNo);
		ResponseEntity<StudentResponse> response=new 
				ResponseEntity<StudentResponse>(studentResponse,HttpStatus.OK);
		return response;
		
	}
	@PostMapping("students")
	@PreAuthorize (value="hasRole('adminrole')")
	public ResponseEntity<StudentRegisteredResponse> persistStudent(@Valid @RequestBody StudentRequest studentRequest,Errors errors){
		//ValidationUtils.invokeValidator(validator, studentRequest, errors);
		
		List<StudentError> studentErrorList=new ArrayList<StudentError>();
		if(errors.hasErrors()) {
			List<ObjectError> list=errors.getAllErrors();
			for(ObjectError error:list) {
				StudentError studentError=new StudentError();
				studentError.setErrorCode(CustomHttpStatus.VALIDATION_FAILED);
				studentError.setErrorMessage(error.getDefaultMessage());
				studentErrorList.add(studentError);
			}
			StudentRegisteredResponse registeredResponse=new StudentRegisteredResponse();
			registeredResponse.setResponseMessage("valiation error");
			registeredResponse.setStudentError(studentErrorList);
			//return  ResponseEntity.ok().body(registeredResponse)
				//	.status(CustomHttpStatus.VALIDATION_FAILED.getVal()).build();
			return new ResponseEntity<StudentRegisteredResponse>(registeredResponse,HttpStatus.BAD_REQUEST);

			
		}else {
			boolean result=studentService.studentRegistrationService(studentRequest);
			if(result) {
				StudentRegisteredResponse registeredResponse=new StudentRegisteredResponse();
				registeredResponse.setResponseMessage("Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registeredResponse,HttpStatus.CREATED);
			}else {
				StudentRegisteredResponse registerdResponse=new StudentRegisteredResponse();
				registerdResponse.setResponseMessage("Not Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registerdResponse,HttpStatus.CONFLICT);

			}
		}
	}
	
	@PutMapping("students")
	@PreAuthorize ("hasRole('adminrole')")
	public ResponseEntity<Void> updateStudent(@RequestBody StudentRequest studentRequest)
	{
		boolean result=studentService.updateStudentService(studentRequest);
		ResponseEntity<Void> response=null;
		if(result==true)
			response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);	
		else
			response=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		return response;
	}

	@PatchMapping("students/{rollNo}/{studentAddress}")
	@PreAuthorize ("hasRole('adminrole')")
	public ResponseEntity<Void> updateInternLevel(@PathVariable("rollNo") int rollNo,@PathVariable("studentAddress")String newAddress)
	{
		boolean result=studentService.updateStudentAddressService(rollNo, newAddress);
		ResponseEntity<Void> response=null;
		if(result==true)
			response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);	
		else
			response=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		return response;
	}
	
	@DeleteMapping("students/{rollNo}")
	@PreAuthorize ("hasRole('adminrole')")
	public ResponseEntity<Void> deleteStudent(@PathVariable("rollNo")int rollNo){
	ResponseEntity<Void> response=null;
    boolean result=studentService.deleteStudentService(rollNo);
    if(result){
			response=new ResponseEntity<Void>(HttpStatus.OK);
		}else{
			response=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		return response;
	}
	
	@GetMapping("x")
	public int x() {
		
		return 10;
	}
	@GetMapping("y")
	public float y() {
		return 10.5f;
	}

}
