package com.yash.proxy;

public interface MyInterface {
	
	public String y(String str);
	

}
