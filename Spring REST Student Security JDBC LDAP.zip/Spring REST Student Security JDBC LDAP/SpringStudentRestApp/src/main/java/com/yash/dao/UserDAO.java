package com.yash.dao;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import com.yash.exception.StudentDAOException;

public interface UserDAO {
	
	public UserDetails getUserDetails(String userName)throws StudentDAOException;

}
