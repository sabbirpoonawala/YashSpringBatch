package com.yash.aspect;
import java.util.List;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.http.ResponseEntity;
import com.yash.model.StudentResponse;

public class LoggingAspect {
	static Logger log = Logger.getLogger(LoggingAspect.class.getName());
	public LoggingAspect() {
		BasicConfigurator.configure();
		log.info("Logger configured successfully");
	}
	public void beforeAdvice(JoinPoint method) {
		log.debug("Log Before advice applied on "+method.getSignature().getName());
	}
	public void afterAdvice(JoinPoint method) {
		log.debug("Log After advice applied on "+method.getSignature().getName());
	}
	public void afterReturning(JoinPoint method,Object result){
		log.debug("Log After returning advice applied on "+method.getSignature().getName() +" returned "+result);
	}
	public void afterThrowing(JoinPoint method,Throwable error){
		log.error("Log After throwing advice applied on "+method.getSignature().getName() +" threw exception "+error);
	}
	public Object aroundAdvice(ProceedingJoinPoint method){
		log.debug("Log Around advice on :"+ method.getSignature().getName());
		ResponseEntity<List<StudentResponse>> response=null;
		try {
			 response=(ResponseEntity<List<StudentResponse>>)method.proceed();		
			 List<StudentResponse> studentResponseList=response.getBody();
			 StudentResponse studentResponse=new StudentResponse();
			 studentResponse.setRollNo(8888);
			 studentResponse.setStudentName("log response modified by around advice logging aspect");
			 studentResponse.setStudentAddress("log response modified by around advice logging aspect");
			 studentResponseList.add(studentResponse);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Log Around advice return value: "+response);
		return response;
	}

}
