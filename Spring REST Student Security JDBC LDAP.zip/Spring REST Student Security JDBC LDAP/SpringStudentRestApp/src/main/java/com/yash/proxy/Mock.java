package com.yash.proxy;

public class Mock {
	
	public void then(String data) {
		System.out.println("then:"+data);
	}

}
