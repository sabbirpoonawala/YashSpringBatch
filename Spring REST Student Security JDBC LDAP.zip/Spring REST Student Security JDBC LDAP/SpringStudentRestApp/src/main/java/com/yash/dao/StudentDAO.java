package com.yash.dao;

import java.util.List;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;

public interface StudentDAO {
	
	public List<Student> getAllStudents()throws StudentDAOException;
	public Student getStudentByRollNo(int rollNo) throws StudentDAOException;
	public boolean registerStudentData(Student student) throws StudentDAOException;
	public boolean updateStudentData(Student student) throws StudentDAOException;
	public boolean updateStudentAddress(int rollNo,String newAddress) throws StudentDAOException;
	public boolean deleteStudent(int rollNo) throws StudentDAOException;
}
