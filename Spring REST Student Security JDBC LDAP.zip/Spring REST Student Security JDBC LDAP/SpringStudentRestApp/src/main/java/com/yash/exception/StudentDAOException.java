package com.yash.exception;

public class StudentDAOException extends Exception{
	private String message;
	public StudentDAOException(Throwable t,String message) {
		super(t);
		this.message=message;
	}
	
	public String getMessage() {
		return message;
	}

}
