package com.yash.model;

import com.yash.custom.CustomHttpStatus;

public class StudentError {
	
	private CustomHttpStatus errorCode;
	private String errorMessage;
	public StudentError() {
	}
	public CustomHttpStatus getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(CustomHttpStatus errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "StudentError [errorCode=" + errorCode + ", errorMessage=" + errorMessage + "]";
	}
	
	

}
