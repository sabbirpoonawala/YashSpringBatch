package com.yash.model;

import java.util.List;

public class StudentRegisteredResponse {
	
	private String responseMessage;
	private List<StudentError> studentError;
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public List<StudentError> getStudentError() {
		return studentError;
	}
	public void setStudentError(List<StudentError> studentError) {
		this.studentError = studentError;
	}
	
	

}
