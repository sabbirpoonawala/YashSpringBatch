package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.yash.controller.StudentController;
import com.yash.dao.StudentDAO;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentController {
	private MockMvc mockMvc;
	
	 @Autowired
	 @Mock
	 private StudentService studentService;
	 
	 @Autowired
	 @Mock
	 private StudentDAO studentDAO; 
	
	 @InjectMocks
	 private StudentController studentController;
	   @Before
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(studentController)
	                .build();
	    }
	@Test
	public void test() {
		System.out.println("Student service:"+studentService.studentRetrievalService());
	ResponseEntity<List<StudentResponse>> response=studentController.retrieveAllStudents();
	List<StudentResponse> studentList=response.getBody();
	assertEquals(true,studentList.size()==0);
	}

}
