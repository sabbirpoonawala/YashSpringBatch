package com.yash.dao;

import java.util.List;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;

public interface StudentDAO {
	
	public List<Student> getAllStudents()throws StudentDAOException;
	public Student getStudentByRollNo(int rollNo) throws StudentDAOException;
	public boolean registerStudentData(Student student) throws StudentDAOException;
}
