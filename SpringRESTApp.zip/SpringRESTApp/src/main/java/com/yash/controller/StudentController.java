package com.yash.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.validation.StudentRequestValidator;

@RestController
@RequestMapping("student-app")
public class StudentController {
	@Autowired
	private StudentService studentService;
	//@Autowired
	//private StudentRequestValidator validator;
	
	@GetMapping("students")
	public ResponseEntity<List<StudentResponse>> retrieveAllStudents(){

		List<StudentResponse> studentResponseList=studentService.studentRetrievalService();
		ResponseEntity<List<StudentResponse>> response=
				new ResponseEntity<List<StudentResponse>>(studentResponseList,HttpStatus.OK);
		return response;
		
	}
	@GetMapping("students/{rollNo}")
	public ResponseEntity<StudentResponse> retrieveStudentByRollNo(@PathVariable("rollNo") int rollNo){
		StudentResponse studentResponse=studentService.studentRetrievalServiceByRollNo(rollNo);
		ResponseEntity<StudentResponse> response=new 
				ResponseEntity<StudentResponse>(studentResponse,HttpStatus.OK);
		return response;
		
	}
	@PostMapping("students")
	public ResponseEntity<String> persistStudent(@Valid @RequestBody StudentRequest studentRequest,Errors errors){
		//ValidationUtils.invokeValidator(validator, studentRequest, errors);
		if(errors.hasErrors()) {
			return new ResponseEntity<String>(String.valueOf(errors.getAllErrors()),HttpStatus.BAD_REQUEST);
		}else {
			boolean result=studentService.studentRegistrationService(studentRequest);
			if(result) {
				return new ResponseEntity<String>("Registered",HttpStatus.CREATED);
			}else {
				return new ResponseEntity<String>("Not Registered",HttpStatus.CONFLICT);

			}
		}
		
		
	}

}
