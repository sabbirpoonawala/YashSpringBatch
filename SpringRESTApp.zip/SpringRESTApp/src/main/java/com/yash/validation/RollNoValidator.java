package com.yash.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class RollNoValidator implements
ConstraintValidator<RollNoConstraint, Integer> {
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		String rollNo=String.valueOf(value);
		if(rollNo.length()<=3)
			return false;
		else
		return true;
	}
	
	public void intialize(RollNoConstraint constraint) {
		
	}
}
